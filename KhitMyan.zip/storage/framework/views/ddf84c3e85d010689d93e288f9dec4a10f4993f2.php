

<?php $__env->startSection('title','Khit Myan'); ?>

<?php
use App\Http\Controllers\Admin\UsersController;
use App\Models\Permission;
$permission = new Permission;
?>


<?php $__env->startSection('content'); ?>

    <div class="container-fluid px-4">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <div class='title-flex'>
        <h1 class="mt-4">Role</h1>
        <?php if($permission->checkPermission('Role create')): ?>
            <a href="<?php echo e(url('admin/Roles/add-content')); ?>" class="btn btn-primary"><i class="fa-solid fa-square-plus"></i>ADD</a>
        <?php else: ?>
            <a class="btn btn-primary"><i class="fas fa-exclamation-triangle"></i></a>
        <?php endif; ?>
        </div>
        <hr>

        <table class="table">
            <thead>
                <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Permissions</th>
                <th scope="col">Created at</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e(++$key); ?></td>
                    <td scope="row"><?php echo e($role->name); ?></td>
                    <td>
                        <ul class="permission-name">
                            <?php $__currentLoopData = $role->permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($permission->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td><?php echo e($role->created_at); ?></td>
                    <td>
                        <div class="d-flex justify-content-center">
                            <?php if($permission->checkPermission('Role view')): ?>
                                <a href="<?php echo e(url('admin/Roles/show-content/'.$role->id)); ?>" class="btn btn-success view"><i class="fa-solid fa-eye"></i></a>
                            <?php else: ?>
                            <a class="btn btn-success view"><i class="fas fa-exclamation-triangle"></i></a>
                            <?php endif; ?>

                            <?php if($permission->checkPermission('Role edit')): ?>
                                <a href="<?php echo e(url('admin/Roles/edit-content/'.$role->id)); ?>" class="btn btn-success edit"><i class="fa-solid fa-pen-to-square"></i></a>
                            <?php else: ?>
                            <a class="btn btn-success edit"><i class="fas fa-exclamation-triangle"></i></a>
                            <?php endif; ?>

                            <?php if($permission->checkPermission('Role delete')): ?>
                                <a href="<?php echo e(url('admin/Roles/delete-content/'.$role->id)); ?>" class="btn btn-danger delete"><i class="fa-solid fa-trash"></i></a>
                            <?php else: ?>
                            <a class="btn btn-danger delete"><i class="fas fa-exclamation-triangle"></i></a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo $roles->links(); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/admin/Roles/index.blade.php ENDPATH**/ ?>