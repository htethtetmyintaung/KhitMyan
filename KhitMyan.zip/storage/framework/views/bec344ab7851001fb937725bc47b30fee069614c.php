

<?php $__env->startSection('title','Khit Myan'); ?>

<?php $__env->startSection('content'); ?>

    <section class="abouttitle padding-top-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-12">
                    <a href="index.html"> <strong>Home</strong> </a> 
                    <span>></span>
                    <span>About</span>
                </div>
                <div class="col-lg-6 col-12 d-flex justify-content-end">
                    <a href="#">Facebook</a> 
                    <span class="mr-5 ml-5"> | </span>
                    <a href="#">Twitter</a>
                </div>
            </div>

            <div>
                <h2 class="text-align-center"><?php echo e($about_contents->title_ja); ?></h2>
                <hr>
            </div>

            <div>
                <img src="images/khitmyan/rsz_khitmyan-logo.jpg" class="w-100" alt="">
                <h3><?php echo e($about_contents->sub_title_ja); ?></h3>
                <p>
                <?php echo e($about_contents->description_ja); ?>

                </p>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.about-ja', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/template/about/detail-ja.blade.php ENDPATH**/ ?>