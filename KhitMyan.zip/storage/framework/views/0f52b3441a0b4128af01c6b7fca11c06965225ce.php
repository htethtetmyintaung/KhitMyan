

<?php $__env->startSection('title','Khit Myan'); ?>

<?php
use App\Http\Controllers\Admin\UsersController;
use App\Models\Permission;
$permission = new Permission;
?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid px-4">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <div class='title-flex'>
        <h1 class="mt-4">About Us</h1>
        <?php if($permission->checkPermission('Template create')): ?>
            <a href="<?php echo e(url('admin/Aboutus/add-content')); ?>" class='btn btn-primary'><i class="fa-solid fa-square-plus"></i>ADD</a>
        <?php else: ?>
            <a class="btn btn-primary"><i class="fas fa-exclamation-triangle"></i></a>
        <?php endif; ?>
        </div>
        <hr>

        <div class="tablescroll">
            <table class="table">
                <thead class="table_bottom">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col" colspan="3">Description</th>
                        <th scope="col">Action</th>
                    </tr>
                    <tr>
                        <th scope="col" ></th>
                        <th scope="col">English</th>
                        <th scope="col">Myanmar</th>
                        <th scope="col">Japan</th>
                        <th scope="col" ></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e(++$key); ?></td>
                        <td>
                            <p><?php echo \Illuminate\Support\Str::words($content->description_en, 5,'....'); ?></p>
                        </td>
                        <td>
                            <p><?php echo \Illuminate\Support\Str::words($content->description_my, 5,'....'); ?></p>
                        </td>
                        <td>
                            <p><?php echo \Illuminate\Support\Str::words($content->description_ja, 5,'....'); ?></p>
                        </td>
                        <td>
                            <div class="d-flex">
                                <?php if($permission->checkPermission('Template view')): ?>
                                    <a href="<?php echo e(url('admin/Aboutus/show-content/'.$content->id)); ?>" class="btn btn-success view"><i class="fa-solid fa-eye"></i></a>
                                <?php else: ?>
                                    <a class="btn btn-success view"><i class="fas fa-exclamation-triangle"></i></a>
                                <?php endif; ?>

                                <?php if($permission->checkPermission('Template edit')): ?>
                                    <a href="<?php echo e(url('admin/Aboutus/edit-content/'.$content->id)); ?>" class="btn btn-success edit"><i class="fa-solid fa-pen-to-square"></i></a>
                                <?php else: ?>
                                    <a class="btn btn-success edit"><i class="fas fa-exclamation-triangle"></i></a>
                                <?php endif; ?>

                                <?php if($permission->checkPermission('Template delete')): ?>
                                    <a href="<?php echo e(url('admin/Aboutus/delete-content/'.$content->id)); ?>" class="btn btn-danger delete"><i class="fa-solid fa-trash"></i></a>
                                <?php else: ?>
                                    <a class="btn btn-danger delete"><i class="fas fa-exclamation-triangle"></i></a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <?php echo $contents->links(); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/admin/Aboutus/index.blade.php ENDPATH**/ ?>