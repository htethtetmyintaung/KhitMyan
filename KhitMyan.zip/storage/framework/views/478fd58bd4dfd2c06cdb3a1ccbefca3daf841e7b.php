

<?php $__env->startSection('title','Khit Myan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
    <div class='title-flex'>
    <h1 class="mt-4"><?php echo e($roles->name); ?></h1>
    <a href="<?php echo e(url('admin/Roles/index')); ?>" class='btn btn-primary'>Go to Back</a>
    </div>
    <hr>
    <dl class="row">
        <dt class="col-sm-3">Role name</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($roles->name); ?></p>
        </dd>

        <dt class="col-sm-3">Created by</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($roles->created_by); ?></p>
        </dd>

        <dt class="col-sm-3">Created at</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($roles->created_at); ?></p>
        </dd>

        <dt class="col-sm-3 text-truncate">Updated at</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($roles->updated_at); ?></p>
        </dd>

        <dt class="col-sm-3">Permissions</dt>
        <dd class="col-sm-9">
            <ul class="permission-name">
                <?php $__currentLoopData = $roles->permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="d-flex">
                    <span class="mr-5">-</span>
                    <p><?php echo e($permission->description); ?></p>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </dd>
    </dl>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/admin/Roles/view.blade.php ENDPATH**/ ?>