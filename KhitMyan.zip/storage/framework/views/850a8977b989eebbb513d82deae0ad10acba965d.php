

<?php $__env->startSection('title','Khit Myan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
    <div class='title-flex'>
    <h1 class="mt-4"><?php echo e($users->name); ?></h1>
    <a href="<?php echo e(url('admin/Users/index')); ?>" class='btn btn-primary'>Go to Back</a>
    </div>
    <hr>
    <dl class="row">
        <dt class="col-sm-3">User name</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($users->name); ?></p>
        </dd>

        <dt class="col-sm-3">Email</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($users->email); ?></p>
        </dd>

        <dt class="col-sm-3">Created by</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($users->created_by); ?></p>
        </dd>

        <dt class="col-sm-3">Created at</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($users->created_at); ?></p>
        </dd>

        <dt class="col-sm-3">Updated at</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($users->updated_at); ?></p>
        </dd>

        <dt class="col-sm-3">Role as</dt>
        <dd class="col-sm-9 ">
            <ul class="permission-name">
                <?php $__currentLoopData = $users->user_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="d-flex">
                    <span class="mr-5">-</span>
                    <p><?php echo e($role->name); ?></p>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </dd>

        <dt class="col-sm-3">Permission</dt>
        <dd class="col-sm-9 ">
            <ul class="permission-name">
            <?php $__currentLoopData = $users->user_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $role->permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="d-flex">
                    <span class="mr-5">-</span>
                    <p><?php echo e($permission->description); ?></p>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </dd>
    </dl>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/admin/Users/view.blade.php ENDPATH**/ ?>