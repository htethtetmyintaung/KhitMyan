

<?php $__env->startSection('title','Khit Myan'); ?>

<?php
use App\Http\Controllers\Admin\UsersController;
use App\Models\Permission;
$permission = new Permission;
?>

<?php $__env->startSection('content'); ?>


    <div class="container-fluid px-4">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <div class='title-flex'>
            <h1 class="mt-4">All Users</h1>
            <?php if($permission->checkPermission('User create')): ?>
                <a href="<?php echo e(url('admin/Users/add-content')); ?>" class='btn btn-primary'><i class="fa-solid fa-square-plus"></i>ADD</a>
            <?php else: ?>
            <a class="btn btn-primary"><i class="fas fa-exclamation-triangle"></i></a>
            <?php endif; ?>
        </div>
        <hr>

        <table class="table">
            <thead>
                <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Role</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e(++$key); ?></td>
                    <td scope="row"><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <ul class="permission-name ">
                        <?php $__currentLoopData = $user->user_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-align-center"><?php echo e($role->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td>
                        <div class="d-flex justify-content-center">
                            <?php if($permission->checkPermission('User view')): ?>
                                <a href="<?php echo e(url('admin/Users/show-content/'.$user->id)); ?>" class="btn btn-success view"><i class="fa-solid fa-eye"></i></a>
                            <?php else: ?>
                            <a class="btn btn-success view"><i class="fas fa-exclamation-triangle"></i></a>
                            <?php endif; ?>

                            <?php if($permission->checkPermission('User edit')): ?>
                                <a href="<?php echo e(url('admin/Users/edit-content/'.$user->id)); ?>" class="btn btn-success edit"><i class="fa-solid fa-pen-to-square"></i></a>
                            <?php else: ?>
                            <a class="btn btn-success edit"><i class="fas fa-exclamation-triangle"></i></a>
                            <?php endif; ?>
                            
                            <?php if($permission->checkPermission('User delete')): ?>
                                <a href="<?php echo e(url('admin/Users/delete-content/'.$user->id)); ?>" class="btn btn-danger delete"><i class="fa-solid fa-trash"></i></a>
                            <?php else: ?>
                            <a class="btn btn-danger delete"><i class="fas fa-exclamation-triangle"></i></a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo $users->links(); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/admin/Users/index.blade.php ENDPATH**/ ?>