<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="Tooplate">

        <title>Khit Myan </title>

        <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/bootstrap-icons.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/tooplate-waso-strategy.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/styles.css')); ?>" rel="stylesheet">

    </head>
    
    <body id="section_1">

    <div >

        <?php echo $__env->make('layouts.frontend.main.navbar-my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main>
                <?php echo $__env->yieldContent('content'); ?>

                <?php echo $__env->make('layouts.frontend.main.home-footer-my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </main>
    </div>
        <!-- JAVASCRIPT FILES -->
        <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.sticky.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

    </body>
</html><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/layouts/home-my.blade.php ENDPATH**/ ?>