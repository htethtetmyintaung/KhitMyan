

<?php $__env->startSection('title','Khit Myan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
    <div class='title-flex'>
    <h1 class="mt-4"><?php echo e($permissions->name); ?></h1>
    <a href="<?php echo e(url('admin/Permissions/index')); ?>" class='btn btn-primary'>Go to Back</a>
    </div>
    <hr>
    <dl class="row">
        <dt class="col-sm-3">Permission name</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($permissions->name); ?></p>
        </dd>

        <dt class="col-sm-3">Created by</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($permissions->created_by); ?></p>
        </dd>

        <dt class="col-sm-3">Created at</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($permissions->created_at); ?></p>
        </dd>

        <dt class="col-sm-3 text-truncate">Updated at</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($permissions->updated_at); ?></p>
        </dd>

        <dt class="col-sm-3">Description</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <p><?php echo e($permissions->description); ?></p>
        </dd>

        <dt class="col-sm-3">User of permission</dt>
        <dd class="col-sm-9 d-flex">
            <span class="mr-5">-</span>
            <ul style="list-style:none;padding: 0px;">
            <?php $__currentLoopData = $permissions->role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $role->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <li><?php echo e($user->name); ?></li>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </dd>
    </dl>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/admin/Permissions/view.blade.php ENDPATH**/ ?>