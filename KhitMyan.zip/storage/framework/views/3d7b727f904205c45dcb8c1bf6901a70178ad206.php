<nav class="navbar navbar-expand-lg bg-white shadow-lg">
    <div class="container">

        <a href="index.html" class="navbar-brand">Khit <span class="text-danger">Myan</span></a>

        <div class="navbar-position w-100">
            <ul class="nav-ul">
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item w-100">
                    <a href="index.html" class="nav-link click-scroll-no "  ><?php echo e($content->title_en); ?></a>
                    <!-- <a href="index.html" class="nav-link click-scroll-no autolang"  ><?php echo e($content->title_my); ?></a> -->
                    <!-- <a href="index.html" class="nav-link click-scroll-no autolang"  ><?php echo e($content->title_ja); ?></a> -->
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
            English
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
            <li><a class="dropdown-item" href="<?php echo e(url('/my')); ?>">Myanmar</a></li>
            <li><a class="dropdown-item" href="<?php echo e(url('/ja')); ?>">Japan</a></li>
        </ul>
        </div>
                
    </div>
</nav><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/layouts/frontend/main/navbar.blade.php ENDPATH**/ ?>