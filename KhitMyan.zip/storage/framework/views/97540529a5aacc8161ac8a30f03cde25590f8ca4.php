

<?php $__env->startSection('title','Khit Myan'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid px-4">
        <h1 class="mt-4">HOME</h1>
        <!-- <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol> -->
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">ENGLISH</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">MYANMAR</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">JAPAN</button>
            </li>
        </ul>
        <form>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <h3>Home (English Language)</h3>
                    <hr>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Banner Title Small</label>
                    <input class="form-control" type="text" id="basicEmailInput" placeholder="">
                    </div>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Banner Title Main</label>
                    <textarea name="" id="" cols="30" rows="5" class="w-100"></textarea>
                    </div>
                </div>
                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <h3>Home (Myanmar Language)</h3>
                    <hr>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Banner Title Small</label>
                    <input class="form-control" type="text" id="basicEmailInput" placeholder="">
                    </div>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Banner Title Main</label>
                    <textarea name="" id="" cols="30" rows="5" class="w-100"></textarea>
                    </div>
                </div>
                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                    <h3>Home (Japan Language)</h3>
                    <hr>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Banner Title Small</label>
                    <input class="form-control" type="text" id="basicEmailInput" placeholder="">
                    </div>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Banner Title Main</label>
                    <textarea name="" id="" cols="30" rows="5" class="w-100"></textarea>
                    </div>
                </div>
            </div>
            <div class="form-group">
            <label for="inputFile">Banner Images</label>
            <input type="file" class="form-control-file" id="inputFile">
            <small class="form-text text-muted"> Upload banner images</small>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/admin/home.blade.php ENDPATH**/ ?>