<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/summernote.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/summernote-lite.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/fontawesome-6.2.1.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/styles.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">

    
</head>
<body class="adminbody">

    <?php echo $__env->make('layouts.backend.admin-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="layoutSidenav">

        <?php echo $__env->make('layouts.backend.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav_content" >
            <main class="admincontents">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
            <?php echo $__env->make('layouts.backend.admin-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/summernote.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/summernote-lite.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/fontawesome-6.2.1.js')); ?>" ></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/layouts/master.blade.php ENDPATH**/ ?>