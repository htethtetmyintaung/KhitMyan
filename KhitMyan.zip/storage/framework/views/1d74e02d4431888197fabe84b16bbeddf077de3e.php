

<?php $__env->startSection('title','Khit Myan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4 mb-5">
        <div class='title-flex'>
        <h1 class="mt-4">Edit Gallery</h1>
        <a href="<?php echo e(url('admin/Galleries/index')); ?>" class='btn btn-primary'>Go to Back</a>
        </div>
        <hr>

        <ul class="nav nav-tabs mb-5" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="english-tab" data-bs-toggle="tab" data-bs-target="#english" type="button" role="tab" aria-controls="home" aria-selected="true">ENGLISH</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="myanmar-tab" data-bs-toggle="tab" data-bs-target="#myanmar" type="button" role="tab" aria-controls="profile" aria-selected="false">MYANMAR</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="japan-tab" data-bs-toggle="tab" data-bs-target="#japan" type="button" role="tab" aria-controls="contact" aria-selected="false">JAPAN</button>
            </li>
        </ul>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <form action="<?php echo e(url('admin/Galleries/update-content/'.$galleries->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="english" role="tabpanel" aria-labelledby="english-tab">
                    <h3>Galleries (English Language)</h3>
                    <hr>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Title</label>
                    <input class="form-control" type="text" name="title_en" id="basicEmailInput" value="<?php echo e($galleries->title_en); ?>">
                    </div>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Sub Title</label>
                    <input class="form-control" type="text" name="sub_title_en" id="basicEmailInput" value="<?php echo e($galleries->sub_title_en); ?>">
                    </div>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Desciption</label>
                    <textarea name="description_en" id="galleries_en_summernote" class="form-control" rows="4"><?php echo e($galleries->description_en); ?></textarea>
                    </div>
                </div>
                <div class="tab-pane fade" id="myanmar" role="tabpanel" aria-labelledby="myanmar-tab">
                    <h3>Galleries (Myanmar Language)</h3>
                    <hr>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Title</label>
                    <input class="form-control" type="text" name="title_my" id="basicEmailInput" value="<?php echo e($galleries->title_my); ?>">
                    </div>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Sub Title</label>
                    <input class="form-control" type="text" name="sub_title_my" id="basicEmailInput" value="<?php echo e($galleries->sub_title_my); ?>">
                    </div>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Desciption</label>
                    <textarea name="description_my" id="galleries_my_summernote" class="form-control" rows="4"><?php echo e($galleries->description_my); ?></textarea>
                    </div>
                </div>
                <div class="tab-pane fade" id="japan" role="tabpanel" aria-labelledby="japan-tab">
                    <h3>Galleries (Japan Language)</h3>
                    <hr>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Title</label>
                    <input class="form-control" type="text" name="title_ja" id="basicEmailInput" value="<?php echo e($galleries->title_ja); ?>">
                    </div>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Sub Title</label>
                    <input class="form-control" type="text" name="sub_title_ja" id="basicEmailInput" value="<?php echo e($galleries->sub_title_ja); ?>">
                    </div>
                    <div class="form-group form-flex">
                    <label for="basicEmailInput">Desciption</label>
                    <textarea name="description_ja" id="galleries_ja_summernote" class="form-control" rows="4"><?php echo e($galleries->description_ja); ?></textarea>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/admin/Galleries/edit.blade.php ENDPATH**/ ?>