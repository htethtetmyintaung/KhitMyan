

<?php $__env->startSection('title','Khit Myan'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid px-4">
        <div class='title-flex'>
        <h1 class="mt-4">Edit Permission</h1>
        <a href="<?php echo e(url('admin/Permissions/index')); ?>" class='btn btn-primary'>Go to Back</a>
        </div>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <form action="<?php echo e(url('admin/Permissions/update-content/'.$permissions->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
            <div class="form-group form-flex">
                <label for="basicEmailInput">Name</label>
                <input class="form-control" type="text" name="permission" value="<?php echo e(old('name',$permissions->name)); ?>" id="basicEmailInput" placeholder="">
            </div>
            <div class="form-group form-flex">
                <label for="basicEmailInput">Description</label>
                <textarea class="w-100" name="description" id="" cols="30" rows="5"><?php echo e(old('description',$permissions->description)); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KhitMyan\resources\views/admin/Permissions/edit.blade.php ENDPATH**/ ?>