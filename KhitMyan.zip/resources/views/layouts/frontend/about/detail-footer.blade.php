<footer class="site-footer">
    <div class="container">
        <div class="row">
            
            <div class="col-lg-6 col-12">
                <a href="index.html" class="navbar-brand navbar-brand-footer">Khit <span class="text-danger">Myan</span></a>
            </div>
            <div class="col-lg-6 col-12">
                <div class="site-footer-wrap d-flex align-items-center justify-content-end detail-social">
                    <p class="copyright-text mb-0 me-4">Khit Myan Co., Ltd.</p>

                    <ul class="social-icon">
                        <li><a href="#" class="social-icon-link bi-facebook"></a></li>

                        <li><a href="#" class="social-icon-link bi-pinterest"></a></li>

                        <li><a href="#" class="social-icon-link bi-twitter"></a></li>

                        <li><a href="#" class="social-icon-link bi-youtube"></a></li>
                    </ul>
                    
                </div>
            </div>
            
            
        </div>
    </div>
</footer>